
//  * LOY 2019 ML.NET Course


Tools->Options->Debugging->Automatically close the console when debugging stops


