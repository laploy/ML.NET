﻿//  * LOY 2019 ML.NET Course
// Build test score and save model

using System;
using System.IO;
using System.Linq;
using Microsoft.ML;
using static Microsoft.ML.DataOperationsCatalog;

namespace _050_DiamondLargeSplit
{
    class Program
    {
        static void Main(string[] args)
        {
            string trainDataPath = @"h:\ml\diamonds-Large-Train.csv";

            // create context
            MLContext mlContext = new MLContext(seed: 0);

            // Load train data
            IDataView trainDataView = mlContext.Data.LoadFromTextFile<DiamondSheme>
                (trainDataPath, hasHeader: true, separatorChar: ',');

            // -------------------------------------------------------------------
            // Create pipeline
            var pipeline = mlContext.Transforms.CopyColumns
                (outputColumnName: "Label", inputColumnName: "Price")

                //  transform the categorical data  values into numbers
                .Append(mlContext.Transforms.Categorical.OneHotEncoding
                    (outputColumnName: "CutNum", inputColumnName: "Cut"))

                .Append(mlContext.Transforms.Categorical.OneHotEncoding
                    (outputColumnName: "ColorNum", inputColumnName: "Color"))

                .Append(mlContext.Transforms.Categorical.OneHotEncoding
                    (outputColumnName: "ClearityNum", inputColumnName: "Clearity"))

                // combines all of the feature columns into the Features column
                .Append(mlContext.Transforms.Concatenate
                    ("Features", "Carat", "CutNum", "ColorNum", "ClearityNum", "Depth",
                    "Table", "LengthX", "WidthY", "DepthZ"))

                // Choose a learning algorithm
                .Append(mlContext.Regression.Trainers.FastTree());

            // ----------------------------------------------------------------------
            // Train the model
            Console.WriteLine($"Strat training. {DateTime.Now}");
            var myModel = pipeline.Fit(trainDataView);
            Console.WriteLine($"Training done. {DateTime.Now}");



            // Split data
            // the TrainTestSplit() method to split the loaded dataset into train and test datasets
            // and return them in the TrainTestData class
            // The default is 10%, in this case you use 20% to evaluate more data
            TrainTestData splitDataView = mlContext.Data.TrainTestSplit
                (trainDataView, testFraction: 0.2);

            // Creates the regression evaluator.
            var predictions = myModel.Transform(trainDataView);

            // -------------------------------------------------------------------------
            // Evaluates the model and creates metrics.
            var metrics = mlContext.Regression.Evaluate(predictions, "Label", "Score");

            Console.WriteLine();
            Console.WriteLine($"*************************************************");
            Console.WriteLine($"* Model quality metrics evaluation ");
            Console.WriteLine($"*------------------------------------------------");

            // RSquared is another evaluation metric of the regression models.
            // RSquared takes values between 0 and 1.The closer its value is to 1, the better the model is
            Console.WriteLine($"* RSquared Score: {metrics.RSquared:0.##}");

            // RMS is one of the evaluation metrics of the regression model. 
            // The lower it is, the better the model is
            Console.WriteLine($"* Root Mean Squared Error: {metrics.RootMeanSquaredError:#.##}");
        }
    }
}
