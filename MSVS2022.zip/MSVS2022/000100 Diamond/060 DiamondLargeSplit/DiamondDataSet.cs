﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.ML.Data;

namespace _060_DiamondLargeSplit
{
    // input data class
    public class DiamondSheme
    {
        [LoadColumn(0)]
        public string Id; // is only column that is NOT feature
        [LoadColumn(1)]
        public float Carat; // The weight of the diamond where 1carat=200mg. 
        [LoadColumn(2)]
        public string Cut; // he quality of the cut (Fair < Good< Very Good< Premium< Ideal) 
        [LoadColumn(3)]
        public string Color;  // Color of the diamond [D (best), E, F, G, H, I, J (worst)] 
        [LoadColumn(4)]
        public string Clearity; //I1 (worst), SI1, SI2, VS1, VS2, VVS1, VVS2, IF (best)
        [LoadColumn(5)]
        public float Depth; // otal depth percentage 
        [LoadColumn(6)]
        public float Table; // Width of top of diamond relative to widest point (43–95) Categorical Variables 
        [LoadColumn(7)]
        public float Price; // this is the Label. The price of the diamond in US dollars ($326–$18,823)
        [LoadColumn(8)]
        public float LengthX; // Length in mm (0–10.74)
        [LoadColumn(9)]
        public float WidthY; // Width in mm (0–58.9) 
        [LoadColumn(10)]
        public float DepthZ; // Depth in mm (0–31.8)
    }
}
