﻿//  * LOY 2019 ML.NET Course
using Microsoft.ML;
using System;

namespace DiamondLarge
{
    class Program
    {
        static void Main(string[] args)
        {
            string trainDataPath = @"h:\ml\diamonds-Large-Train.csv";
            string scoreDataPath = @"h:\ml\diamonds-Large-Score.csv";

            // create context
            MLContext mlContext = new MLContext(seed: 0);
            
            // Load train data
            IDataView dataView = mlContext.Data.LoadFromTextFile<DiamondSheme>
                (trainDataPath, hasHeader: true, separatorChar: ',');

            // -------------------------------------------------------------------
            // create pipeline
            var pipeline = mlContext.Transforms.CopyColumns
                (outputColumnName: "Label", inputColumnName: "Price")

                //  transform the categorical data  values into numbers
                .Append(mlContext.Transforms.Categorical.OneHotEncoding 
                    (outputColumnName: "CutNum", inputColumnName: "Cut"))

                .Append(mlContext.Transforms.Categorical.OneHotEncoding
                    (outputColumnName: "ColorNum", inputColumnName: "Color"))

                .Append(mlContext.Transforms.Categorical.OneHotEncoding
                    (outputColumnName: "ClearityNum", inputColumnName: "Clearity"))

                // combines all of the feature columns into the Features column
                .Append(mlContext.Transforms.Concatenate
                    ("Features", "Carat", "CutNum", "ColorNum", "ClearityNum", "Depth", 
                    "Table", "LengthX", "WidthY", "DepthZ"))

                // Choose a learning algorithm
                .Append(mlContext.Regression.Trainers.FastTree());

            // ----------------------------------------------------------------------
            // Train the model
            Console.WriteLine($"Strat training. {DateTime.Now}");
            var model = pipeline.Fit(dataView);
            Console.WriteLine($"Training done. {DateTime.Now}");

            // Loads the test dataset.
            dataView = mlContext.Data.LoadFromTextFile<DiamondSheme>
                (scoreDataPath, hasHeader: true, separatorChar: ',');

            // Creates the regression evaluator.
            var predictions = model.Transform(dataView);

            // -------------------------------------------------------------------------
            // Evaluates the model and creates metrics.
            var metrics = mlContext.Regression.Evaluate(predictions, "Label", "Score");

            Console.WriteLine();
            Console.WriteLine($"*************************************************");
            Console.WriteLine($"* Model quality metrics evaluation ");
            Console.WriteLine($"*------------------------------------------------");

            // RSquared is another evaluation metric of the regression models.
            // RSquared takes values between 0 and 1.The closer its value is to 1, the better the model is
            Console.WriteLine($"* RSquared Score: {metrics.RSquared:0.##}");

            // RMS is one of the evaluation metrics of the regression model. 
            // The lower it is, the better the model is
            Console.WriteLine($"* Root Mean Squared Error: {metrics.RootMeanSquaredError:#.##}");

            //-----------------------------------------------------------------------------
            // Test Single Prediction

            // create engine
            var predictionFunction = mlContext.Model.CreatePredictionEngine
                <DiamondSheme, DiamondPredict>(model);

            // make one test diamond data we want to predict
            var myPredict = new DiamondSheme()
            {
                Id = "34973",
                Carat = 0.83f,
                Cut = "Very Good",
                Color = "G",
                Clearity = "SI2",
                Depth = 63.1f,
                Table = 61f,
                Price = 2259f,
                LengthX = 5.96f,
                WidthY = 5.92f,
                DepthZ = 3.75f
            };

            // make prediction
            var prediction = predictionFunction.Predict(myPredict);

            Console.WriteLine();
            Console.WriteLine($"**********************************************************************");
            Console.WriteLine($"Predicted diamond price: {prediction.ScorePrice:0.##}, actual price: 2259");
            Console.WriteLine($"**********************************************************************");
        }
    }
}

/*
 * output
 * 
Strat training. 6/11/2019 11:27:38 AM
Training done. 6/11/2019 11:27:39 AM

*************************************************
* Model quality metrics evaluation
*------------------------------------------------
* RSquared Score: 1
* Root Mean Squared Error: 255.29

**********************************************************************
Predicted diamond price: 2591.82, actual price: 2259
**********************************************************************
 * 
 */
