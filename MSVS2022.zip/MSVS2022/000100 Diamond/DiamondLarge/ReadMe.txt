﻿//  * LOY 2019 ML.NET Course
Predict diamond price using large dataset (35,000 rows)

Build, evaluate and test in one program.

Azure AI Gallery
https://github.com/laploy/ML.NET/tree/master/Diamond%20Large

Project resources
https://github.com/laploy/ML.NET/tree/master/Diamond%20Large

Train DataSet
https://raw.githubusercontent.com/laploy/ML.NET/master/Diamond%20Large/diamonds-Large-Train.csv

Score DataSet
https://github.com/laploy/ML.NET/blob/master/Diamond%20Large/diamonds-Large-Score.csv

Test DataSet
https://github.com/laploy/ML.NET/blob/master/Diamond%20Large/diamonds-Large-Test.csv

