﻿//  * LOY 2019 ML.NET Course

// Predict one diamond using saved model
// with build-in one test data record

using System;
using System.IO;
using System.Linq;
using Microsoft.ML;

namespace DiamondPredict
{
    class Program
    {
        static void Main(string[] args)
        {
            string modelPath = @"h:\ml\diamondsModel.zip";
            // Create context
            MLContext mlContext = new MLContext(seed: 0);

            // Load Model
            ITransformer loadedModel = mlContext.Model.Load(modelPath, out var modelInputSchema);

            // Make one test diamond data we want to predict
            var myDiamond = new DiamondSheme()
            {
                Id = "34973",
                Carat = 0.83f,
                Cut = "Very Good",
                Color = "G",
                Clearity = "SI2",
                Depth = 63.1f,
                Table = 61f,
                Price = 2259f,
                LengthX = 5.96f,
                WidthY = 5.92f,
                DepthZ = 3.75f
            };

            // Create a PredictionEngine
            PredictionEngine<DiamondSheme, DiamondPredict> predEngine = 
                mlContext.Model.CreatePredictionEngine<DiamondSheme, DiamondPredict>(loadedModel);

            // Use the PredictionEngine to predict the diamond price
            var prediction = predEngine.Predict(myDiamond);

            Console.WriteLine();
            Console.WriteLine($"**********************************************************************");
            Console.WriteLine($"Predicted diamond price: {prediction.ScorePrice:0.##}, actual price: 2259");
            Console.WriteLine($"**********************************************************************");
        }
    }
}
