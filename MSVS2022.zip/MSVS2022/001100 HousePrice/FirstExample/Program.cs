﻿/*
 * LOY 2019 ML.NET Course
 * 
 Code Flow
 = = = = = = = 
Collect and load training data into an IDataView object

Specify a pipeline of operations to extract features and apply a machine learning algorithm

Algorithm = SdcaRegression

Train a model by calling Fit() on the pipeline

Evaluate the model and iterate to improve

Save the model into binary format, for use in an application

Load the model back into an ITransformer object

Make predictions by calling CreatePredictionEngine.Predict()
 */



using System;
using Microsoft.ML;
using Microsoft.ML.Data;
class Program
{
    public class HouseData
    {
        public float Size { get; set; }
        public float Price { get; set; }
    }
    public class Prediction
    {
        [ColumnName("Score")]
        public float Price { get; set; }
    }

    static void Main(string[] args)
    {
        MLContext mlContext = new MLContext();

        // 1. Import or create training data
        HouseData[] houseData = {
            new HouseData() { Size = 1.1F, Price = 1.2F },
            new HouseData() { Size = 1.9F, Price = 2.3F },
            new HouseData() { Size = 2.8F, Price = 3.0F },
            new HouseData() { Size = 3.4F, Price = 3.7F } };
        IDataView trainingData = mlContext.Data.LoadFromEnumerable(houseData);

        // 2. Specify data preparation and model training pipeline
            // concat to feature
        var pipeline = mlContext.Transforms.Concatenate("Features", new[] { "Size" })
            // set algorithm
            .Append(mlContext.Regression.Trainers.Sdca(labelColumnName: "Price", maximumNumberOfIterations:100));

        // 3. Train model
        var model = pipeline.Fit(trainingData);

        // Model evaluation
        HouseData[] testHouseData =
        {
            new HouseData() { Size = 1.1F, Price = 0.98F },
            new HouseData() { Size = 1.9F, Price = 2.1F },
            new HouseData() { Size = 2.8F, Price = 2.9F },
            new HouseData() { Size = 3.4F, Price = 3.6F }
        };
        var testHouseDataView = mlContext.Data.LoadFromEnumerable(testHouseData);
        // The resulting model object implements the ITransformer interface. 
        // That is, the model transforms input data into predictions.
        var testPriceDataView = model.Transform(testHouseDataView);

        // use debug watch to peek the data
        var debug = testPriceDataView.Preview();

        var metrics = mlContext.Regression.Evaluate(testPriceDataView, labelColumnName: "Price");
        Console.WriteLine($"R^2: {metrics.RSquared:0.##}");
        Console.WriteLine($"RMS error: {metrics.RootMeanSquaredError:0.##}");
        // R^2: 0.96
        // RMS error: 0.19


        // 4. Make a prediction
        var size = new HouseData() { Size = 2.5F };
        var price = mlContext.Model.CreatePredictionEngine<HouseData, Prediction>(model).Predict(size);
        // or you can write in 2 lines
        // var predEngine = model.CreatePredictionEngine<HouseData, Prediction>(mlContext);
        // var price = predEngine.Predict(size);

        // Predicted price for size: 2500 sq ft= $261.98k
        Console.WriteLine($"Predicted price for size: {size.Size * 1000} sq ft= {price.Price * 100:C}k");


        // save the model for use in the prediction application.
        mlContext.Model.Save(model, trainingData.Schema, @"h:\ml\model.zip");
    }
}