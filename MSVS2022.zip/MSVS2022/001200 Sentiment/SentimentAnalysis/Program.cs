﻿// LOY 2019 ML.NET Course
// Manage NuGet Packages
// Microsoft.ML
// Microsoft.ML.FastTree

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.ML;
using Microsoft.ML.Data;
using static Microsoft.ML.DataOperationsCatalog;

namespace SentimentAnalysis
{
    class Program
    {
        // path to the dataset used to train the model.
        static readonly string _dataPath = Path.Combine
            (Environment.CurrentDirectory, "Data","yelp_labelled.txt");

        static void Main(string[] args)
        {
            // The MLContext class is a starting point for all ML.NET operations
            // Initializing mlContext creates a new ML.NET environment that can be 
            // shared across the model creation workflow objects.
            // It's similar, conceptually, to DBContext in Entity Framework.
            MLContext mlContext = new MLContext();

            // Load data
            TrainTestData splitDataView = LoadData(mlContext);

            /* Preview dataset
                SamplingKeyColumnName
                ====================
                The dataset column to use for grouping rows. 
                If two examples share the same sampling key column name, 
                they are guaranteed to appear in the same subset (train or test). 
                This can be used to ensure no "label leakage" from the train 
                to the test set. If null, no row grouping will be performed.
             */
            var aaaa = splitDataView.TrainSet.Preview();

            // build and train model
            ITransformer model = BuildAndTrainModel(mlContext, splitDataView.TrainSet);

            // Evaluate model
            Evaluate(mlContext, model, splitDataView.TestSet);

            // use model with single item
            UseModelWithSingleItem(mlContext, model);

            //Use Model With Batch Items
            UseModelWithBatchItems(mlContext, model);

            //Use Model With Batch Items from file
            UseModelWithBatchItemsFromFile(mlContext, model);

            Console.WriteLine();
            Console.WriteLine("=============== End of process ===============");
        }

        public static TrainTestData LoadData(MLContext mlContext)
        {
            // 1. Load data
            // The LoadFromTextFile() defines the data schema and reads in the file.
            // our dataset has no header
            IDataView dataView = mlContext.Data.LoadFromTextFile<SentimentData>(_dataPath, hasHeader: false);

            // 2. split data
            // the TrainTestSplit() method to split the loaded dataset into train and test datasets
            // and return them in the TrainTestData class
            // The default is 10%, in this case you use 20% to evaluate more data
            TrainTestData splitDataView = mlContext.Data.TrainTestSplit(dataView, testFraction: 0.2);

            // 3. Returns the split train and test datasets
            return splitDataView;
        }

        public static ITransformer BuildAndTrainModel(MLContext mlContext, IDataView splitTrainSet)
        {

            // 1. Extracts and transforms the data
            // The FeaturizeText() method converts the text column 
            // ( SentimentText ) into a numeric key type Features column
            // and adds it as a new dataset column
            // SamplingKeyColumn
            var estimator = mlContext.Transforms.Text.FeaturizeText(outputColumnName: "Features", 
                inputColumnName:nameof(SentimentData.SentimentText))

            // 2. Add algorithm
            // classification algorithm
            // Microsoft.ML.Trainers.SdcaLogisticRegressionBinaryTrainer, which predicts
            // a target using a linear classification model.
            // This is appended to the estimator and accepts the featurized SentimentText ( Features ) 
            // and the Label input parameters to learn fromthe historic data.	
            .Append(mlContext.BinaryClassification.Trainers.SdcaLogisticRegression(labelColumnName: "Label",
                featureColumnName: "Features"));

            // 3. Train the model
            // Fit the model to the splitTrainSet data
            Console.WriteLine("=============== Create and Train the Model ===============");
            var model = estimator.Fit(splitTrainSet);
            Console.WriteLine("=============== End of training ===============");
            Console.WriteLine();
     
            // 4. Return the model trained to use for evaluation
            return model;
        }

        public static void Evaluate(MLContext mlContext, ITransformer model, IDataView splitTestSet)
        {
            // Evaluate the model and show accuracy stats

            //Take the data in, make transformations, output the data. 
            Console.WriteLine("=============== Evaluating Model accuracy with Test data ===============");
            IDataView predictions = model.Transform(splitTestSet);

            // BinaryClassificationContext.Evaluate returns a BinaryClassificationEvaluator.CalibratedResult
            // that contains the computed overall metrics.
            CalibratedBinaryClassificationMetrics metrics = mlContext.BinaryClassification.Evaluate(predictions, "Label");

            // The Accuracy metric gets the accuracy of a model, which is the proportion 
            // of correct predictions in the test set.

            // The AreaUnderROCCurve metric is equal to the probability that the algorithm ranks
            // a randomly chosen positive instance higher than a randomly chosen negative one
            // (assuming 'positive' ranks higher than 'negative').

            // The F1Score metric gets the model's F1 score.
            // The F1 score is the harmonic mean of precision and recall:
            //  2 * precision * recall / (precision + recall).

            Console.WriteLine();
            Console.WriteLine("Model quality metrics evaluation");
            Console.WriteLine("--------------------------------");
            Console.WriteLine($"Accuracy: {metrics.Accuracy:P2}");
            Console.WriteLine($"Auc: {metrics.AreaUnderRocCurve:P2}");
            Console.WriteLine($"F1Score: {metrics.F1Score:P2}");
            Console.WriteLine("=============== End of model evaluation ===============");
        }

        private static void UseModelWithSingleItem(MLContext mlContext, ITransformer model)
        {
            // Create Prediction Engine1
            PredictionEngine<SentimentData, SentimentPrediction> predictionFunction = 
                mlContext.Model.CreatePredictionEngine<SentimentData, SentimentPrediction>(model);

            // Create Test Issue1
            SentimentData sampleStatement = new SentimentData
            {
                SentimentText = "This was a very bad steak"
            };

            // Predict
            var resultprediction = predictionFunction.Predict(sampleStatement);


            // Output Prediction
            Console.WriteLine();
            Console.WriteLine("=============== Prediction Test of model with a single sample and test dataset ===============");


            Console.WriteLine();
            Console.WriteLine($"Sentiment: {resultprediction.SentimentText} | Prediction: {(Convert.ToBoolean(resultprediction.Prediction) ? "Positive" : "Negative")} | Probability: {resultprediction.Probability} ");

            // result
            // Sentiment: This was a very bad steak | Prediction: Negative | Probability: 0.11102406

            /*
             *  The Scored Probabilities column shows the probability that a text belongs to 
             *  the Negative class. For example, the Probability: 0.11102406 
             *  means there is 0.11102406 probability that the text belongs to Negative class.
            */

            Console.WriteLine("=============== End of Predictions ===============");
            Console.WriteLine();
        }

        public static void UseModelWithBatchItems(MLContext mlContext, ITransformer model)
        {
            // Adds some comments to test the trained model's data points.
            // Create Test Issues
            IEnumerable<SentimentData> sentiments = new[]
            {
                new SentimentData
                {
                    SentimentText = "This was a horrible meal"
                },
                new SentimentData
                {
                    SentimentText = "I love this spaghetti."
                }
            };

            // Load batch comments just created 
            // Prediction
            IDataView batchComments = mlContext.Data.LoadFromEnumerable(sentiments);
            IDataView predictions = model.Transform(batchComments);

            // Use model to predict whether comment data is Positive (1) or Negative (0).
            IEnumerable<SentimentPrediction> predictedResults = mlContext.Data.CreateEnumerable<SentimentPrediction>
                (predictions, reuseRowObject: false);

            // Add InfoMessage
            Console.WriteLine();
            Console.WriteLine("=============== Prediction Test of loaded model with multiple samples ===============");
            Console.WriteLine();

            // Display Results
            foreach (SentimentPrediction prediction in predictedResults)
            {
                Console.WriteLine($"Sentiment: {prediction.SentimentText} | Prediction: " +
                    $"{(Convert.ToBoolean(prediction.Prediction) ? "Positive" : "Negative")} | " +
                    $"Probability: {prediction.Probability} ");

            }
            Console.WriteLine("=============== End of predictions ===============");
            Console.WriteLine();
        }

        public static void UseModelWithBatchItemsFromFile(MLContext mlContext, ITransformer model)
        {
            // add BatchSentiments.txt to data folder and change property to "Copy if newer"
            string batchSentimentsPath = Path.Combine(Environment.CurrentDirectory, "Data", "BatchSentiments.txt");
            string[] lines = System.IO.File.ReadAllLines(batchSentimentsPath);
            SentimentData[] sentimentsData = new SentimentData[lines.Count()];
            for (int i = 0; i < lines.Count(); i++)
            {
                sentimentsData[i] = new SentimentData { SentimentText = lines[i] };
            }

            // Load batch comments just created 
            // Prediction
            IDataView batchComments = mlContext.Data.LoadFromEnumerable(sentimentsData);
            IDataView predictions = model.Transform(batchComments);

            // Use model to predict whether comment data is Positive (1) or Negative (0).
            IEnumerable<SentimentPrediction> predictedResults = mlContext.Data.CreateEnumerable<SentimentPrediction>
                (predictions, reuseRowObject: false);

            // Add InfoMessage
            Console.WriteLine();
            Console.WriteLine("========== Prediction Test with multiple samples from file ==========");
            Console.WriteLine();

            // Display Results
            foreach (SentimentPrediction prediction in predictedResults)
            {
                Console.WriteLine($"Sentiment: {prediction.SentimentText} | Prediction: " +
                    $"{(Convert.ToBoolean(prediction.Prediction) ? "Positive" : "Negative")} | " +
                    $"Probability: {prediction.Probability} ");

            }
            Console.WriteLine("=============== End of predictions ===============");
        }
    }
}
