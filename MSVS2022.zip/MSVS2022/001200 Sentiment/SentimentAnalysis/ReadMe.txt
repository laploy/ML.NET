﻿//  * LOY 2019 ML.NET Course

SentimentAnalysis
https://github.com/dotnet/samples/tree/master/machine-learning/tutorials/SentimentAnalysis


Tutorial: Analyze sentiment of website comments with binary classification in ML.NET

Algorithm = Microsoft.ML.Trainers.SdcaLogisticRegressionBinaryTrainer

This tutorial shows you how to create a .NET Core console application that classifies sentiment from website
comments and takes the appropriate action. The binary sentiment classifier

Create a console application
Prepare data
Load the data
Build and train the model
Evaluate the model
Use the model to make a prediction
See the results

Dataset
Download UCI Sentiment Labeled Sentences dataset ZIP file, and unzip
Copy the yelp_labelled.txt file into the Data directory you created
In Solution Explorer, right-click the yelp_labeled.txt file and select Properties. Under Advanced, change
Create classes and define paths the value of Copy to Output Directory to "Copy if newer""

https://archive.ics.uci.edu/ml/machine-learning-databases/00331/sentiment%20labelled%20sentences.zip


How the data was prepared

The input dataset class, SentimentData , has a string for user comments ( SentimentText ) and a bool ( Sentiment
) value of either 1 (positive) or 0 (negative) for sentiment. Both fields have LoadColumn attributes attached to
them, which describes the data file order of each field. In addition, the Sentiment property has a ColumnName
attribute to designate it as the Label field. 


SENTIMENTTEXT									SENTIMENT (LABEL)
Waitress was a little slow in service.				0
Crust is not good.									0
Wow... Loved this place.							1
Service was very prompt.							1




Accuracy
In classification, accuracy is the number of correctly classified items divided by the total 
number of items in the test set. Ranges from 0 (least accurate) to 1 (most accurate). 
Accuracy is one of evaluation metrics of the model performance. 
Consider it in conjunction with precision, recall, and F-score.

Area under the curve (AUC)
In binary classification, an evaluation metric that is the value of the area 
under the curve that plots the true positives rate (on the y-axis) against the false 
positives rate (on the x-axis). Ranges from 0.5 (worst) to 1 (best). 
Also known as the area under the ROC curve, i.e., receiver operating characteristic curve. 

F-score
In classification, an evaluation metric that balances precision and recall.

Precision
In classification, the precision for a class is the number of items correctly 
predicted as belonging to that class divided by the total number of items predicted 
as belonging to the class.

Recall
In classification, the recall for a class is the number of items correctly 
predicted as belonging to that class divided by the total number of items that 
actually belong to the class.
