﻿
//  * LOY 2019 ML.NET Course

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.ML.Data;

namespace SentimentAnalysis
{
    // input dataset class
    public class SentimentData
    {
        // LoadColumn attributes describes the data file order of each field
        [LoadColumn(0)]
        public string SentimentText;

        // ColumnName attribute Allows one to specify a name to expose this column as, 
        // as opposed to the default behavior of using the member name as the column name.
        [LoadColumn(1), ColumnName("Label")]
        public bool Sentiment;
    }

    // prediction class used after the model training
    public class SentimentPrediction : SentimentData
    {
        // used during prediction and evaluation
        [ColumnName("PredictedLabel")]
        public bool Prediction { get; set; }

        public float Probability { get; set; }
        public float Score { get; set; }
    }
}

