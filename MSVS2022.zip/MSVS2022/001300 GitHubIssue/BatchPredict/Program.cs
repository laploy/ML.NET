﻿//  * LOY 2019 ML.NET Course
// Predict batch from file


using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.ML;

namespace BatchPredict
{
    class Program
    {
        static void Main(string[] args)
        {
            // Set data set path
            string testDataPath = @"h:\ml\issues_batch.tsv";
            string modelPath = @"h:\ml\issue_model.zip";

            Console.WriteLine("program start");
            // Create context
            MLContext mlContext = new MLContext(seed: 0);

            // Read test file
            string[] lines = File.ReadAllLines(testDataPath);

            // Create issue object array
            // - 2 because first line is header
            Issue[] myTest = new Issue[lines.Count() - 2];

            // Assign value to each object in array
            for (int i = 1; i < lines.Count() - 1; i++)
            {
                string[] myArray = lines[i].ToString().Split('\t');

                // Make one test diamond data we want to predict
                int j = 0;
                var myIssue = new Issue()
                {
                    ID = myArray[j++],
                    Area = myArray[j++],
                    Title = myArray[j++],
                    Description = myArray[j++],
                };
                myTest[i - 1] = myIssue;
            }

            // Load from enumberable
            IDataView batchView = mlContext.Data.LoadFromEnumerable(myTest);

            // Load Model
            ITransformer loadedModel = mlContext.Model.Load(modelPath, out var modelInputSchema);

            // Create prediction view
            IDataView predictions = loadedModel.Transform(batchView);

            // Create enumerable prediction
            IEnumerable<Predict> predictedResults = mlContext.Data.CreateEnumerable<Predict>
                (predictions, reuseRowObject: false);

            // Display Results
            Console.WriteLine("==== Prediction with multiple rows from file ===");
            Console.WriteLine("--------------------------------------------------");
            foreach (Predict prediction in predictedResults)
            {
                Console.WriteLine($"Actual price: {prediction.Area} \t\t| Predicted price: {prediction.PredictArea}");
            }
            Console.WriteLine("=============== End of predictions ===============");
            Console.ReadKey();
        }
    }
}
