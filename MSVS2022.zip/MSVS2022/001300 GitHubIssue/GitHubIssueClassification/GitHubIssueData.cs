﻿
//  * LOY 2019 ML.NET Course

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.ML.Data;

namespace GitHubIssueClassification
{
    // input dataset class
    public class GitHubIssue
    {
        [LoadColumn(0)] // Maps member to specific field in text file.
        public string ID { get; set; } // GitHub Issue ID
        [LoadColumn(1)]
        public string Area { get; set; } // the prediction for training
        [LoadColumn(2)]
        public string Title { get; set; } // GitHub issue title
        [LoadColumn(3)]
        public string Description { get; set; } // the second feature used for predicting the Area
    }

    // class used for prediction after the model has been trained. It has a single string ( Area )
    // and a PredictedLabel ColumnName attribute.The PredictedLabel is used during
    public class IssuePrediction
    {
        [ColumnName("PredictedLabel")]      // Label used during prediction and evaluation
        public string Area;
    }
}




