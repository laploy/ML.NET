﻿//  * LOY 2019 ML.NET Course
// Install the Microsoft.ML NuGet Package
// Download the issues_train.tsv and the issues_test.tsv data sets and save them to the Data folder
// Set each data file Properties. Under Advanced, change the value of Copy to Output Directory to "Copy if newer".

using System;
using System.IO;
using System.Linq;
using Microsoft.ML;

namespace GitHubIssueClassification
{
    class Program
    {
        /*
            _trainDataPath has the path to the dataset used to train the model.
            _testDataPath has the path to the dataset used to evaluate the model.
            _modelPath has the path where the trained model is saved.

            _mlContext is the MLContext that provides processing context.
            _trainingDataView is the IDataView used to process the training dataset.
            _predEngine is the PredictionEngine<TSrc,TDst> used for single predictions.
         */
        private static string _trainDataPath = Path.Combine(Environment.CurrentDirectory, "Data", "issues_train.tsv");
        private static string _testDataPath = Path.Combine(Environment.CurrentDirectory, "Data", "issues_test.tsv");

        private static string _appPath => Path.GetDirectoryName(Environment.GetCommandLineArgs()[0]);
        private static string _modelPath => Path.Combine(_appPath, "..", "..", "..", "Models", "issue_model.zip");

        private static MLContext _mlContext;
        private static PredictionEngine<GitHubIssue, IssuePrediction> _predEngine;
        private static ITransformer _trainedModel;
        static IDataView _trainingDataView;


        static void Main(string[] args)
        {
            // random seed ( seed: 0 ) for repeatable / deterministic 
            // results across multiple trainings
            _mlContext = new MLContext(seed: 0);

            // Load the data
            _trainingDataView = _mlContext.Data.LoadFromTextFile<GitHubIssue>
                (_trainDataPath, hasHeader: true);

            // The ProcessData method executes the following tasks:
            //      Extracts and transforms the data.
            //      Returns the processing pipeline.
            var pipeline = ProcessData();

            // Build and train the model
            /*
            The BuildAndTrainModel method executes the following tasks:
                    Creates the training algorithm class.
                    Trains the model.
                    Predicts area based on training data.
                    Returns the model.
             */
            var trainingPipeline = BuildAndTrainModel(_trainingDataView, pipeline);


            // Evaluate the model
            /*
            The Evaluate method executes the following tasks:
                    Loads the test dataset.
                    Creates the multiclass evaluator.
                    Evaluates the model and create metrics.
                    Displays the metrics.
             */
            // model created in BuildAndTrainModel is passed in to be evaluated
            Evaluate(_trainingDataView.Schema);

            // save model for use in later Prediction
            _mlContext.Model.Save(_trainedModel, _trainingDataView.Schema, _modelPath);

            // Deploy and Predict with a model
            /*
            The PredictIssue method executes the following tasks:
                * Creates a single issue of test data.
                * Predicts Area based on test data.
                * Combines test data and predictions for reporting.
                * Displays the predicted results.
             */
            PredictIssue();
        }

        public static IEstimator<ITransformer> ProcessData()
        {
            // Extract Features and transform the data
            // use the MapValueToKey() method to transform the Area column into a numeric key type
            var pipeline = _mlContext.Transforms.Conversion.MapValueToKey
                (inputColumnName: "Area", outputColumnName:"Label")

                // transforms the text Title columns into a numeric vector
                .Append(_mlContext.Transforms.Text.FeaturizeText
                (inputColumnName: "Title", outputColumnName:"TitleFeaturized"))

                // transforms the text Description columns into a numeric vector
                .Append(_mlContext.Transforms.Text.FeaturizeText
                (inputColumnName: "Description", outputColumnName:"DescriptionFeaturized"))

                // combines all of the feature columns into the Features column using the Concatenate() method
                .Append(_mlContext.Transforms.Concatenate
                ("Features", "TitleFeaturized", "DescriptionFeaturized"))

                // cache the DataView so when you iterate over the data multiple times 
                // using the cache might get better performance
                // Do NOT use it (remove .AppendCacheCheckpoint()) when handling very large datasets.
                .AppendCacheCheckpoint(_mlContext);

            return pipeline;
        }

        public static IEstimator<ITransformer> BuildAndTrainModel
            (IDataView trainingDataView, IEstimator<ITransformer>pipeline)
        {
            // Append the machine learning algorithm to the data transformation definitions
            var trainingPipeline =

                // The SdcaMaximumEntropy is your multiclass classification training algorithm
                pipeline.Append(_mlContext.MulticlassClassification.Trainers.SdcaMaximumEntropy("Label", "Features"))

                // Method MapKeyToValue() convert numberic value to Label's value
                .Append(_mlContext.Transforms.Conversion.MapKeyToValue("PredictedLabel"));

            // Train the model
            // Fit the model to the splitTrainSet data and return the trained model
            Console.WriteLine();
            Console.WriteLine($"========== Training Start {DateTime.Now.ToString("hh:mm:ss.fff ")} ==========");
            _trainedModel = trainingPipeline.Fit(trainingDataView);
            Console.WriteLine($"========== Training Done {DateTime.Now.ToString("hh:mm:ss.fff ")} ==========");
            return trainingPipeline;
        }

        public static void Evaluate(DataViewSchema trainingDataViewSchema)
        {
            // evaluate it with a different dataset for quality assurance and validation.

            // load the test dataset
            var testDataView = _mlContext.Data.LoadFromTextFile<GitHubIssue>(_testDataPath, hasHeader: true);

            // computes the quality metrics for the model
            // It returns a MulticlassClassificationMetrics object that contains the 
            // overall metrics computed by multiclass classification evaluators.

            // Using the Transform() to input the features and return predictions
            var testMetrics = _mlContext.MulticlassClassification.Evaluate(_trainedModel.Transform(testDataView));


            /*
            The following metrics are evaluated for multiclass classification:

                * Micro Accuracy - Every sample-class pair contributes equally to the accuracy metric. 
                  You want Micro Accuracy to be as close to 1 as possible.

                * Macro Accuracy - Every class contributes equally to the accuracy metric. 
                  Minority classes are given equal weight as the larger classes. 
                  You want Macro Accuracy to be as close to 1 as possible.

                * Log-loss - see Log Loss. You want Log-loss to be as close to zero as possible.
                
                * Log-loss reduction - Ranges from [-inf, 100], where 100 is perfect predictions and 0 indicates mean
                  predictions. You want Log-loss reduction to be as close to zero as possible.

            *****************************************************************************
            * Metrics for Multi-class Classification model - Test Data
            *----------------------------------------------------------------------------
            * MicroAccuracy: 0.737
            * MacroAccuracy: 0.667
            * LogLoss: .915
            * LogLossReduction: .645
            ****************************************************************************
             */

            // Displaying the metrics for model validation
            Console.WriteLine();
            Console.WriteLine($"*****************************************************************************");
            Console.WriteLine($"* Metrics for Multi-class Classification model - Test Data ");
            Console.WriteLine($"*----------------------------------------------------------------------------");
            Console.WriteLine($"* MicroAccuracy: {testMetrics.MicroAccuracy:0.###}");
            Console.WriteLine($"* MacroAccuracy: {testMetrics.MacroAccuracy:0.###}");
            Console.WriteLine($"* LogLoss: {testMetrics.LogLoss:#.###}");
            Console.WriteLine($"* LogLossReduction: {testMetrics.LogLossReduction:#.###}");
            Console.WriteLine($"****************************************************************************");
        }

        private static void PredictIssue()
        {
            ITransformer loadedModel = _mlContext.Model.Load(_modelPath, out var modelInputSchema);

            // Add a GitHub issue to test the trained model's prediction
            GitHubIssue singleIssue = new GitHubIssue()
            {
                Title = "Entity Framework crashes",
                Description = "When connecting to the database, EF is crashing"
            };

            // create a PredictionEngine
            _predEngine = _mlContext.Model.CreatePredictionEngine<GitHubIssue, IssuePrediction>(loadedModel);

            // Use the PredictionEngine to predict the Area GitHub label
            var prediction = _predEngine.Predict(singleIssue);

            //Using the loaded model for prediction
            Console.WriteLine();
            Console.WriteLine($"=============== Single Prediction - Result: {prediction.Area} ===============");
        }
    }
}
