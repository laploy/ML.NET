﻿//  * LOY 2019 ML.NET Course

Tutorial: Categorize support issues using multiclass classification with ML .NET

This sample tutorial illustrates using ML.NET to create a GitHub issue classifier to train a model that classifies and
predicts the Area label for a GitHub issue via a .NET Core console application using C# in Visual Studio.


In this tutorial, you learn how to:
	Prepare your data
	Transform the data
	Train the model
	Evaluate the model
	Predict with the trained model
	Deploy and Predict with a loaded model



DataSet

The Github issues tab separated file (issues_train.tsv).
https://raw.githubusercontent.com/dotnet/samples/master/machine-learning/tutorials/GitHubIssueClassification/Data/issues_train.tsv


The Github issues test tab separated file (issues_test.tsv).
https://raw.githubusercontent.com/dotnet/samples/master/machine-learning/tutorials/GitHubIssueClassification/Data/issues_test.tsv


Dataset has 4 column

1. ID
2. Area
3. Title
4. Description

******************* Warining ****************************
You may need to add a text file to the Models folder and make it "Copy if changed"
to make sure we will have this folder in the debug output too.