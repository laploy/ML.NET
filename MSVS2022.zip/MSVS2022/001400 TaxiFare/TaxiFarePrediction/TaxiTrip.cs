﻿//  * LOY 2019 ML.NET Course

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.ML.Data;

namespace TaxiFarePrediction
{
    // input data class
    public class TaxiTrip
    {
        [LoadColumn(0)]
        public string VendorId; // is a feature
        [LoadColumn(1)]
        public string RateCode; // is a feature
        [LoadColumn(2)]
        public float PassengerCount; // is a feature
        [LoadColumn(3)]
        public float TripTime;  // is NOT a feature
        [LoadColumn(4)]
        public float TripDistance; // is a feature
        [LoadColumn(5)]
        public string PaymentType; // is a feature
        [LoadColumn(6)]
        public float FareAmount; // is a Label
    }

    // output data class
    public class TaxiTripFarePrediction
    {
        // In case of the regression task the Score column contains predicted label
        [ColumnName("Score")]
        // Use the float type to represent floating-point values in the input and prediction data classes.
        public float FareAmount;    // is the prediction output
    }
}
