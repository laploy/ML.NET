﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace AdultML.Models
{
    public partial class mldbContext : DbContext
    {
        public mldbContext()
        {
        }

        public mldbContext(DbContextOptions<mldbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Adult> Adult { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=.\\SQLExpress;Database=mldb;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.4-servicing-10062");

            modelBuilder.Entity<Adult>(entity =>
            {
                entity.ToTable("adult");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .ValueGeneratedNever();

                entity.Property(e => e.Age).HasColumnName("age");

                entity.Property(e => e.CapitalGain).HasColumnName("capital_gain");

                entity.Property(e => e.CapitalLoss).HasColumnName("capital_loss");

                entity.Property(e => e.Education)
                    .IsRequired()
                    .HasColumnName("education")
                    .HasMaxLength(50);

                entity.Property(e => e.EducationNum).HasColumnName("education_num");

                entity.Property(e => e.Ethnicity)
                    .IsRequired()
                    .HasColumnName("ethnicity")
                    .HasMaxLength(50);

                entity.Property(e => e.Fnlwgt).HasColumnName("fnlwgt");

                entity.Property(e => e.HoursPerWeek).HasColumnName("hours_per_week");

                entity.Property(e => e.Label).HasColumnName("label");

                entity.Property(e => e.MaritalStatus)
                    .IsRequired()
                    .HasColumnName("marital_status")
                    .HasMaxLength(50);

                entity.Property(e => e.NativeCountry)
                    .IsRequired()
                    .HasColumnName("native_country")
                    .HasMaxLength(50);

                entity.Property(e => e.Occupation)
                    .IsRequired()
                    .HasColumnName("occupation")
                    .HasMaxLength(50);

                entity.Property(e => e.Relationship)
                    .IsRequired()
                    .HasColumnName("relationship")
                    .HasMaxLength(50);

                entity.Property(e => e.Sex)
                    .IsRequired()
                    .HasColumnName("sex")
                    .HasMaxLength(50);

                entity.Property(e => e.Workclass)
                    .IsRequired()
                    .HasColumnName("workclass")
                    .HasMaxLength(50);
            });
        }
    }
}
