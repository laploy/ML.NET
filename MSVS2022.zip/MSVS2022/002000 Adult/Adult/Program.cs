﻿using System;
using System.Linq;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.ML;
using Microsoft.ML.Transforms;
using AdultML.Models;

namespace AdultML
{
    class Program
    {
        private static IEnumerable<Adult> QueryData()
        {
            using (var db = new mldbContext())
            {
                foreach (var v in db.Adult.AsNoTracking().OrderBy(x => x.Id))
                {
                    yield return v;
                }
            }
        }

        static void Main(string[] args)
        {
            var mlContext = new MLContext(seed: 1);
            var dataView = mlContext.Data.LoadFromEnumerable(QueryData());
            var trainTestData = mlContext.Data.TrainTestSplit(dataView);

            var pipeline = mlContext.Transforms.Categorical.OneHotEncoding(new[] {
                        new InputOutputColumnPair("MsOHE", "MaritalStatus"),
                        new InputOutputColumnPair("OccOHE", "Occupation"),
                        new InputOutputColumnPair("RelOHE", "Relationship"),
                        new InputOutputColumnPair("SOHE", "Sex"),
                        new InputOutputColumnPair("NatOHE", "NativeCountry")
                    }, OneHotEncodingEstimator.OutputKind.Binary)
    .Append(mlContext.Transforms.Concatenate("Features", "MsOHE", "OccOHE", "RelOHE", "SOHE", "NatOHE"))
    .Append(mlContext.BinaryClassification.Trainers.LightGbm());


            Console.WriteLine("Training model...");
            var model = pipeline.Fit(trainTestData.TrainSet);

            Console.WriteLine("Predicting...");
            var predictions = model.Transform(trainTestData.TestSet);

            var metrics = mlContext.BinaryClassification.Evaluate(predictions);

            ConsoleHelper.PrintBinaryClassificationMetrics("Database Example", metrics);
            ConsoleHelper.ConsolePressAnyKey();
        }
    }
}
