﻿Create the data model

ML.NET enables you to define data models via classes

