﻿//  * LOY 2019 ML.NET Course

using System;
using Microsoft.ML;
using Microsoft.ML.Data;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;


namespace test
{
    class Diamond
    {
        [LoadColumn(0)]
        public float Size { get; set; }
        [LoadColumn(1)]
        public float Price { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //Create MLContext
            MLContext mlContext = new MLContext();

            // Create TextLoader
            TextLoader textLoader = mlContext.Data.
                CreateTextLoader<Diamond>
                (separatorChar: ',', 
                hasHeader: true);

            var path1 = @"h:/ml/folder1/diamonds01.csv";
            var path2 = @"h:/ml/folder2/diamonds02.csv";

            // Load Data
            IDataView data = textLoader.Load(path1, path2);

            // show column Size
            IEnumerable<float> sizeColumn = data.GetColumn<float>
                ("Size").ToList();
            foreach (var v in sizeColumn)
                Console.WriteLine(v);
        }
    }
}
