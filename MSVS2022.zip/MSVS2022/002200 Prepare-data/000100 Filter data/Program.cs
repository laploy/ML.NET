﻿//  * LOY 2019 ML.NET Course

using System;
using Microsoft.ML;
using Microsoft.ML.Data;
using System.Collections.Generic;
using System.Linq;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create MLContext
            MLContext mlContext = new MLContext();

            //Load Data
            IDataView data = mlContext.Data.LoadFromTextFile<Diamond>(
                @"h:\ml\diamond1.csv",
                separatorChar: ',',
                hasHeader: true);

            // Apply filter
            IDataView filteredData = mlContext.Data.FilterRowsByColumn(
                data, "Price", 
                lowerBound: 500, 
                upperBound: 1000);

            IEnumerable<float> c1 = data.GetColumn<float>
                ("Price").ToList();
            Console.WriteLine("-----------show all Price-------- ");
            foreach (var v in c1)
                Console.WriteLine(v);

            IEnumerable<float> c2 = filteredData.GetColumn<float>
                ("Price").ToList();
            Console.WriteLine("-----------show filltered Price-------- ");
            foreach (var v in c2)
                Console.WriteLine(v);
        }
    }
}
