﻿-----------show all Price--------
7366
NaN
544
NaN
493
3011
11413
-----------show replace missing Price--------
7366
4565.4
544
4565.4
493
3011
11413