﻿//  * LOY 2019 ML.NET Course

using System;
using Microsoft.ML;
using Microsoft.ML.Data;
using System.Collections.Generic;
using System.Linq;
using Microsoft.ML.Transforms;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create MLContext
            MLContext mlContext = new MLContext();

            //Load Data
            IDataView data = mlContext.Data.LoadFromTextFile<Diamond>(
                @"h:\ml\diamond1.csv",
                separatorChar: ',',
                hasHeader: true);

            // Define min-max estimator
            var estimator = mlContext.Transforms.NormalizeMinMax(
                inputColumnName: "Price",
                outputColumnName: "Price2");

            // Fit data to estimator
            // Fitting generates a transformer that applies the operations of defined by estimator
            ITransformer replacementTransformer = estimator.Fit(data);

            // Transform data
            IDataView transformedData = replacementTransformer.Transform(data);


            IEnumerable<float> c1 = data.GetColumn<float>
                ("Price").ToList();
            Console.WriteLine("-----------show all Price-------- ");
            foreach (var v in c1)
                Console.WriteLine(v);

            IEnumerable<float> c2 = transformedData.GetColumn<float>
                ("Price2").ToList();
            Console.WriteLine("-----------show normalized Price-------- ");
            foreach (var v in c2)
                Console.WriteLine(v);


        }
    }
}
