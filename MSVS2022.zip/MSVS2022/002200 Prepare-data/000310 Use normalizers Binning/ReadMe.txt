﻿
Binning

Binning converts continuous values into a discrete representation of the input. 
For example, suppose one of yourfeatures is age. Instead of using the actual 
age value, binning creates ranges for that value. 0-18 could be one bin,
another could be 19-35 and so on


-----------show all Price--------
7366
985
544
9140
493
3011
11413
-----------show normalized Binning--------
0.5		<------ bin .5
0.5
0		<------ bin 0
1
0
0.5
1		<------ bin 1