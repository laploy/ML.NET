﻿//  * LOY 2019 ML.NET Course

using System;
using Microsoft.ML;
using Microsoft.ML.Data;
using System.Collections.Generic;
using System.Linq;
using Microsoft.ML.Transforms;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create MLContext
            MLContext mlContext = new MLContext();

            //Load Data
            IDataView data = mlContext.Data.LoadFromTextFile<AdultSmall>(
                @"h:\ml\adultSmall.csv",
                separatorChar: ',',
                hasHeader: true);

            // Define categorical transform estimator
            var estimator = mlContext.Transforms.Categorical.OneHotEncoding(
                inputColumnName: "WorkClass",
                outputColumnName: "WorkClass2");

            // Fit data to estimator
            // Fitting generates a transformer that applies the operations of defined by estimator
            ITransformer categoricalTransformer = estimator.Fit(data);

            // Transform Data
            IDataView transformedData = categoricalTransformer.Transform(data);

            IEnumerable<string> c1 = data.GetColumn<string>
                ("WorkClass").ToList();
            Console.WriteLine("-----------show column Workclass-------- ");
            foreach (var v in c1)
                Console.WriteLine(v);

            IEnumerable<float[]> c2 = transformedData.GetColumn<float[]>
                ("WorkClass2").ToList();
            Console.WriteLine("-----------show column Workclass2-------- ");
            foreach (var v in c2)
            {
                foreach (var k in v)
                    Console.Write(k);
                Console.WriteLine();
            }
        }
    }
}
