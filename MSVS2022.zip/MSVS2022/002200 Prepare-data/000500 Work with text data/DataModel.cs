﻿//  * LOY 2019 ML.NET Course
using Microsoft.ML.Data;

using System;
using System.Collections.Generic;
using System.Text;

namespace test
{
    public class SentimentData
    {
        [LoadColumn(0)]
        public string Message;

        [LoadColumn(1)]
        public bool Label;
    }
}
