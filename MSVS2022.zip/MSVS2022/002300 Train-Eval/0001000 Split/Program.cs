﻿//  * LOY 2019 ML.NET Course

using System;
using Microsoft.ML;
using Microsoft.ML.Data;
using System.Collections.Generic;
using System.Linq;
using Microsoft.ML.Transforms;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create MLContext
            MLContext mlContext = new MLContext();

            //Load Data
            IDataView data = mlContext.Data.LoadFromTextFile<AdultSmall>(
                @"h:\ml\adultSmall.csv",
                separatorChar: ',',
                hasHeader: true);


            DataOperationsCatalog.TrainTestData dataSplit = mlContext.Data.TrainTestSplit(
                data, 
                testFraction: 0.2);
            IDataView trainData = dataSplit.TrainSet;
            IDataView testData = dataSplit.TestSet;

            // ========================= console write ===================
            var myPreview = data.Preview();

            Console.WriteLine("\n-----------show original data-------- ");

            for (int k = 0; k < myPreview.Schema.Count(); k++)
                Console.Write($"{myPreview.Schema[k]}\t");

            Console.WriteLine("\n----------------------------------- ");

            for (int j = 0; j < myPreview.RowView.Count(); j++)
            {
                for (int i = 0; i < myPreview.ColumnView.Count() - 1; i++)
                {
                    var v = myPreview.ColumnView[i].Values.GetValue(j);
                    Console.Write($"{v}\t");
                }
                Console.WriteLine();
            }

            IEnumerable<int> c1 = data.GetColumn<int>("Id").ToList();
            Console.WriteLine("\n-----------show all row-------- ");
            foreach (var v in c1)
                Console.Write(v + ", ");

            IEnumerable<int> c2 = trainData.GetColumn<int>("Id").ToList();
            Console.WriteLine("\n\n-----------Train data-------- ");
            foreach (var v in c2)
                Console.Write(v + ", ");

            IEnumerable<int> c3 = testData.GetColumn<int>("Id").ToList();
            Console.WriteLine("\n\n-----------Test data-------- ");
            foreach (var v in c3)
                Console.Write(v + ", ");
            Console.WriteLine("\n");
        }
    }
}
