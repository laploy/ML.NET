﻿//  * LOY 2019 ML.NET Course

using System;
using Microsoft.ML;
using Microsoft.ML.Data;
using System.Collections.Generic;
using System.Linq;
using Microsoft.ML.Transforms;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            ShowConcat();
            ShowConcatAndNormalize();
        }
        public static void ShowConcat()
        {
            //Create MLContext
            MLContext mlContext = new MLContext();

            //Load Data
            IDataView data = mlContext.Data.LoadFromTextFile<IrisData>(
                @"h:\ml\iris-data-train.csv",
                separatorChar: ',',
                hasHeader: true);

            // Define Data Prep Estimator
            IEstimator<ITransformer> estimator =

                // 1. Concatenate SepalLength and SepalWidth into a single feature vector 
                // output to a new column called Features
                mlContext.Transforms.Concatenate("Features", "SepalLength", "SepalWidth");

            // Create data prep transformer
            ITransformer pepData = estimator.Fit(data);

            // Apply tranforms to training data
            IDataView transData = pepData.Transform(data);


            // ============ console write ===========================
            Preview(data);
            IEnumerable<float[]> c1 = transData.GetColumn<float[]>
                ("Features").ToList();
            Console.WriteLine("\n-----------show Concatenate-------- ");
            foreach (var v in c1)
            {
                foreach (var k in v)
                    Console.Write(k + ", ");
                Console.WriteLine();
            }
        }
        public static void ShowConcatAndNormalize()
        {
            //Create MLContext
            MLContext mlContext = new MLContext();

            //Load Data
            IDataView data = mlContext.Data.LoadFromTextFile<IrisData>(
                @"h:\ml\iris-data-train.csv",
                separatorChar: ',',
                hasHeader: true);

            // Define Data Prep Estimator
            // 1. Concatenate Size and Historical into a single feature vector output to a new column called Features
            // 2. Normalize Features vector
            IEstimator<ITransformer> dataPrepEstimator =
            mlContext.Transforms.Concatenate("Features", "SepalLength", "SepalWidth")
            .Append(mlContext.Transforms.NormalizeMinMax("Features"));
            // Create data prep transformer
            ITransformer dataPrepTransformer = dataPrepEstimator.Fit(data);
            // Apply tranforms to training data
            IDataView transformedTrainingData = dataPrepTransformer.Transform(data);


            // ============ console write ===========================
            IEnumerable<float[]> c1 = transformedTrainingData.GetColumn<float[]>
                ("Features").ToList();
            Console.WriteLine("\n-----------show Concatenate & Normalize-------- ");
            foreach (var v in c1)
            {
                foreach (var k in v)
                    Console.Write(k + ", ");
                Console.WriteLine();
            }
        }
        public static void Preview(IDataView data)
        {
            var myPreview = data.Preview();
            Console.WriteLine("\n-----------show original data-------- ");

            for (int k = 0; k < myPreview.Schema.Count(); k++)
                Console.Write($"{myPreview.Schema[k]} | ");
            Console.WriteLine("\n----------------------------------- ");

            for (int j = 0; j < myPreview.RowView.Count(); j++)
            {
                for (int i = 0; i < myPreview.ColumnView.Count() - 1; i++)
                {
                    var v = myPreview.ColumnView[i].Values.GetValue(j);
                    Console.Write($"{v}\t");
                }
                Console.WriteLine();
            }
        }
    }
}
